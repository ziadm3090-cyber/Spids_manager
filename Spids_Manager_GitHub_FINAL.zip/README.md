# Spids Manager — GitHub Pages

Version complète basée sur la dernière version V11 du projet.

Contenu :
- Dashboard global
- Chantiers
- Finance
- Dépenses / encaissements
- Fournisseurs
- Ouvriers
- Matériaux
- Stock
- Réunions
- Documents
- Factures
- Échantillons
- Photos / caméra
- Planning
- Sauvegarde locale dans le navigateur
- Interface adaptée iPhone / Safari
- PWA / ajout à l'écran d'accueil

Pour GitHub Pages : le fichier principal est `index.html`.
